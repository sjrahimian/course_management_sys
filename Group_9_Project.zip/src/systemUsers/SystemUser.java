package systemUsers;

public interface SystemUser{
	
	void setName(String name);
	void setSurname(String surname);
	void setID(String ID);
	
	String getName();
	String getSurname();
	String getID();
	
}
