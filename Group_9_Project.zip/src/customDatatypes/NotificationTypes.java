package customDatatypes;

public enum NotificationTypes {
	EMAIL, CELLPHONE, MAIL, PIGEON_POST
}
